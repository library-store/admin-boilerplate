<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Labels Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used in labels throughout the system.
    | Regardless where it is placed, a label can be listed here so it is easily
    | found in a intuitive way.
    |
    */

    'general' => [
        'all'                => 'Tất cả',
        'yes'                => 'Có',
        'no'                 => 'Không',
        'copyright'          => 'Copyright',
        'custom'             => 'Custom',
        'actions'            => 'Hành dộng',
        'active'             => 'Hoạt động',
        'buttons'            => [
            'save'   => 'Save',
            'update' => 'Update',
        ],
        'hide'               => 'Ẩn',
        'inactive'           => 'Không hoạt động',
        'none'               => 'None',
        'show'               => 'Hiển thị',
        'toggle_navigation'  => 'Toggle Navigation',
        'create_new'         => 'Tạo mới',
        'toolbar_btn_groups' => 'Toolbar with button groups',
        'more'               => 'Xem thêm',
        'none'               => 'None',
    ],

    'backend' => [
        'access'  => [
            'roles' => [
                'create'     => 'Tạo vai trò',
                'edit'       => 'Sửa vai trò',
                'management' => 'Quản lý vai trò',

                'table' => [
                    'number_of_users' => 'Number of Users',
                    'permissions'     => 'Quyền',
                    'role'            => 'Vai trò',
                    'sort'            => 'Sắp xếp',
                    'total'           => 'role total|roles total',
                ],
            ],

            'users' => [
                'active'              => 'Active Users',
                'all_permissions'     => 'Tất cả Quyền',
                'change_password'     => 'Đổi mật khẩu',
                'change_password_for' => 'Đổi mật khẩu cho :user',
                'create'              => 'Tạo thành viên mới',
                'deactivated'         => 'Deactivated Users',
                'deleted'             => 'Deleted Users',
                'edit'                => 'Sửa thành viên',
                'management'          => 'Quản lý thành viên',
                'no_permissions'      => 'No Permissions',
                'no_roles'            => 'No Roles to set.',
                'permissions'         => 'Quyền',
                'user_actions'        => 'User Actions',

                'table' => [
                    'confirmed'         => 'Confirmed',
                    'created'           => 'Created',
                    'email'             => 'E-mail',
                    'id'                => 'ID',
                    'last_updated'      => 'Last Updated',
                    'name'              => 'Tên',
                    'first_name'        => 'Họ',
                    'last_name'         => 'Tên',
                    'no_deactivated'    => 'No Deactivated Users',
                    'no_deleted'        => 'No Deleted Users',
                    'other_permissions' => 'Other Permissions',
                    'permissions'       => 'Permissions',
                    'abilities'         => 'Abilities',
                    'roles'             => 'Roles',
                    'social'            => 'Social',
                    'total'             => 'user total|users total',
                ],

                'tabs' => [
                    'titles' => [
                        'overview' => 'Overview',
                        'history'  => 'History',
                    ],

                    'content' => [
                        'overview' => [
                            'avatar'        => 'Avatar',
                            'confirmed'     => 'Confirmed',
                            'created_at'    => 'Created At',
                            'deleted_at'    => 'Deleted At',
                            'email'         => 'E-mail',
                            'last_login_at' => 'Last Login At',
                            'last_login_ip' => 'Last Login IP',
                            'last_updated'  => 'Last Updated',
                            'name'          => 'Name',
                            'first_name'    => 'Họ',
                            'last_name'     => 'Tên',
                            'status'        => 'Status',
                            'timezone'      => 'Timezone',
                        ],
                    ],
                ],

                'view' => 'View User',
            ],
        ],
        'product' => [
            'product'  => [
                'product'          => 'Sản phẩm',
                'product_category' => 'Danh mục sản phẩm',
                'name'             => 'Tên sản phẩm',
                'category'         => 'Danh mục',
                'management'       => 'Quản lý sản phẩm',
                'create'           => 'Thêm sản phẩm',
                'edit'             => 'Sửa sản phẩm',
                'delete'           => 'Xóa sản phẩm'
            ],
            'category' => [

            ]

        ],
    ],

    'frontend' => [

        'auth' => [
            'login_box_title'    => 'Login',
            'login_button'       => 'Login',
            'login_with'         => 'Login with :social_media',
            'register_box_title' => 'Register',
            'register_button'    => 'Register',
            'remember_me'        => 'Remember Me',
        ],

        'contact' => [
            'box_title' => 'Contact Us',
            'button'    => 'Send Information',
        ],

        'passwords' => [
            'expired_password_box_title'      => 'Your password has expired.',
            'forgot_password'                 => 'Forgot Your Password?',
            'reset_password_box_title'        => 'Reset Password',
            'reset_password_button'           => 'Reset Password',
            'update_password_button'          => 'Update Password',
            'send_password_reset_link_button' => 'Send Password Reset Link',
        ],

        'user' => [
            'passwords' => [
                'change' => 'Change Password',
            ],

            'profile' => [
                'avatar'             => 'Avatar',
                'created_at'         => 'Created At',
                'edit_information'   => 'Edit Information',
                'email'              => 'E-mail',
                'last_updated'       => 'Last Updated',
                'name'               => 'Name',
                'first_name'         => 'Họ',
                'last_name'          => 'Tên',
                'update_information' => 'Update Information',
            ],
        ],

    ],
];
